
-- X by Ghuul (2023)

local _, X = ...
local XF = CreateFrame('Frame', nil);

----------------------------------------

XF:RegisterEvent('PLAYER_LOGIN');
XF:SetScript('OnEvent', function()
   X_Cache = X_Cache or {}
   X_Cache_Char = X_Cache_Char or {}
end)

----------------------------------------

function X:SetV(LABEL,VALUE,CHAR)
   if CHAR then X_Cache_Char[LABEL] = VALUE;
   else X_Cache[LABEL] = VALUE; end
end

----------------------------------------

function X:GetV(LABEL,CHAR)
   if CHAR then return X_Cache_Char[LABEL] or nil;
   else return X_Cache[LABEL] or nil; end
end

----------------------------------------

function X:IsModuleActive(NAME)
   return X.modules[NAME]
end

----------------------------------------

function X:SetDebug(MODULE,STATE)
   X.D = X.D or {}
   X.D[MODULE] = STATE
   
   if STATE == true then
      print("[X] "..string.upper(MODULE).." debug is ".. string.upper(tostring(STATE)) ..".")
   end
end

function X:IsDebugMode(MODULE)
    return X.D[MODULE] or false;
end

function X:Debug(MODULE,...)
   X.D[MODULE] = X.D[MODULE] or false
   if X.D[MODULE] == true then
      print("[X:"..string.upper(MODULE).."] ".. strjoin("",...) ..".")
   end
end

----------------------------------------

XF:EnableKeyboard(true)
XF:SetPropagateKeyboardInput(true)
XF:SetScript("OnKeyDown", function(self,KEY)
   if KEY == "<" then
      if GameTooltip:GetItem() ~= nil then
         DevTools_Dump(X:GetItemInfo(select(2, GameTooltip:GetItem())));
      elseif GameTooltip:GetUnit() ~= nil then
         local _,_,_,_,_, creature_id = strsplit('-', UnitGUID('mouseover'));
         print("[X] Creature ID: ".. creature_id);
      end
   elseif KEY == "'" then X_InitiateCleaner();
    elseif KEY == 'å' then X_InitiateMerhant(); end
end)