
-- X by Ghuul (2023)

local _, X = ...

X.Transmog = {
   ["DRUID"] = {
      ["Armor"] = {2,5},
      ["Weapon"] = {4,5,6,10,13,15}
   },
   ["DEATHKNIGHT"] = {
      ["Armor"] = {4,5},
      ["Weapon"] = {0,1,4,5,6,7,8}
   },
   ["DEMONHUNTER"] = {
      ["Armor"] = {2,5},
      ["Weapon"] = {0,7,9,13}
   },
   ["EVOKER"] = {
      ["Armor"] = {3,5},
      ["Weapon"] = {0,4,7,10,13,15}
   },
   ["HUNTER"] = {
      ["Armor"] = {3,5},
      ["Weapon"] = {0,1,2,3,6,7,8,10,13,15,18}
   },
   ["MAGE"] = {
      ["Armor"] = {1,5},
      ["Weapon"] = {7,10,15,19}
   },
   ["MONK"] = {
      ["Armor"] = {2,5},
      ["Weapon"] = {0,4,6,7,10,13}
   },
   ["PALADIN"] = {
      ["Armor"] = {4,5,6},
      ["Weapon"] = {0,1,4,5,6,7,8}
   },
   ["PRIEST"] = {
      ["Armor"] = {1,5},
      ["Weapon"] = {4,10,15,19}
   },
   ["ROGUE"] = {
      ["Armor"] = {2,5},
      ["Weapon"] = {0,2,3,4,7,13,15,16}
   },
   ["SHAMAN"] = {
      ["Armor"] = {3,5,6},
      ["Weapon"] = {0,1,4,5,10,13,15}
   },
   ["WARLOCK"] = {
      ["Armor"] = {1,5},
      ["Weapon"] = {4,10,15,19}
   },
   ["WARRIOR"] = {
      ["Armor"] = {4,5,6},
      ["Weapon"] = {0,1,2,3,4,5,6,7,8,10,13,15,16,18}
   }
}

----------------------------------------

function X:PlayerCanUseItem(ITEM)
   local class = X:GetPlayerClass()
   return tContains(X.Transmog[class][ITEM.type], ITEM.subtypeID)
end

function X:PlayerHasTransmog(ITEM)
   return C_TransmogCollection.PlayerHasTransmogByItemInfo(ITEM.link)
end