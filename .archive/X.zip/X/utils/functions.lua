
-- X by Ghuul (2023)

local _, X = ...

----------------------------------------

function X:GetItemInfo(LINK)
   local item = {}
   
   item.name,
   item.link,
   item.quality,
   item.baseilvl,
   item.reqlevel,
   item.type,
   item.subtype,
   item.stackcount,
   item.equiploc,
   item.texture,
   item.sellprice,
   item.typeID,
   item.subtypeID,
   item.bindtype,
   item.expacID,
   item.setID,
   item.crafting = GetItemInfo(LINK);
   
   if item ~= nil then
        item.ID = tonumber(string.match(LINK, "^.-:(%d+):"));
      item.ilvl = GetDetailedItemLevelInfo(LINK);
      item.expacID, item.expacname = X:GetExpansion(item);
      item.qualitytier = select(3,string.find(LINK,'Tier(%d):')) or nil;
   end
   
   return item
end

----------------------------------------

function X:GetExpansion(ITEM)
   local xpaclist = {
      [0] = 'Classic',
      [1] = 'Burning Crusade',
      [2] = 'Wrath of the Lich King',
      [3] = 'Cataclysm',
      [4] = 'Mists of Pandaria',
      [5] = 'Warlords of Draenor',
      [6] = 'Legion',
      [7] = 'Battle for Azeroth',
      [8] = 'Shadowlands',
      [9] = 'Dragonflight'
   }
   
   local fixed_items = {
      -- Classic
      ['Crunchy Spider Leg'] = 0,
      
      -- Wrath of the Lich King
      ['Conqueror\'s Mark of Sanctification'] = 2,
      ['Glow Worm'] = 2,
      ['Protector\'s Mark of Sanctification'] = 2,
      ['Sewer Carp'] = 2,
      ['Shimmering Minnow'] = 2,
      ['Slippery Eel'] = 2,      
      ['Vanquisher\'s Mark of Sanctification'] = 2,
      
      -- Mists of Pandaria
      ['Plump Intestines'] = 4,
      
      -- Shadowlands
      ['Questionable Mawshrooms'] = 8
   }
   
   if fixed_items[ITEM.name] then
      ITEM.expacID = fixed_items[ITEM.name]
   end
   
   return ITEM.expacID, xpaclist[ITEM.expacID] or 'Unknown'
end

----------------------------------------

function X:GetFactionInfo(INDEX)
   local faction = {}
   
   faction.name,
   faction.description,
   faction.standingId,
   faction.bottomValue,
   faction.topValue,
   faction.earnedValue,
   faction.atWarWith,
   faction.canToggleAtWar,
   faction.isHeader,
   faction.isCollapsed,
   faction.hasRep,
   faction.isWatched,
   faction.isChild,
   faction.ID = GetFactionInfo(INDEX)
   
   return faction
end

----------------------------------------

function X:GetPlayerLevel()
   return UnitLevel('player')
end

----------------------------------------

function X:GetPlayerClass()
   return select(2, UnitClass('player'))
end

----------------------------------------

function X:GetProfessions()
   local P1,P2 = GetProfessions()
   if P1 ~= nil then P1 = GetProfessionInfo(P1) end
   if P2 ~= nil then P2 = GetProfessionInfo(P2) end
   
   return P1,P2
end

----------------------------------------

function X:PlayerHasProfession(NAME)
   return tContains({X:GetProfessions()}, NAME)
end

----------------------------------------

function X:GetMountInfo(ID)
   local mount = {}
   
   mount.name,
   mount.ID,
   mount.icon,
   mount.active,
   mount.isUsable,
   mount.sourceType,
   mount.isFavorite,
   mount.isFactionSpecific,
   mount.faction,
   mount.hideOnChar,
   mount.isCollected = C_MountJournal.GetMountInfoByID(ID)
   
   return mount
end

----------------------------------------

function X:PlayerHasMount(NAME)
   local mount_list = C_MountJournal.GetMountIDs()
   for i = 1, #mount_list do
      local mount = X:GetMountInfo(mount_list[i])
      if mount.name == NAME then
         return mount.isCollected
      end
   end
end

----------------------------------------

function X:GetColor(NAME)
   if type(NAME) == 'table' then
      return unpack(NAME) 
   end
   
   local colors = {
      ['white'] = {1,1,1},
      ['black'] = {0,0,0},
      ['default'] = {nil,nil,nil}
      }
   
   return unpack(colors[NAME] or colors['default'])
end

----------------------------------------

function X:NumToChar(n)
   local char_list = {
      [0] = 'a',[1] = 'b',[2] = 'c',[3] = 'd',[4] = 'e',[5] = 'f',[6] = 'g',[7] = 'h',[8] = 'i',[9] = 'j',[10] = 'k',
      [11] = 'l',[12] = 'm',[13] = 'n',[14] = 'o',[15] = 'p',[16] = 'q',[17] = 'r',[18] = 's',[19] = 't',[20] = 'u',
      [21] = 'v',[22] = 'x',[23] = 'y',[24] = 'z'}
   
   return char_list[n]
end

----------------------------------------

function X:Increment(VALUE,AMOUNT)
   AMOUNT = AMOUNT or 1
   return VALUE + AMOUNT
end

function X:Reduce(VALUE,AMOUNT)
   AMOUNT = AMOUNT or 1
   return VALUE - AMOUNT
end

----------------------------------------

function X:RemoveTableValue(TABLE,VALUE)
   local new_table = {}
   for i = 1, #TABLE do
      if TABLE[i] ~= VALUE then
         tinsert(new_table,TABLE[i])
      end
   end
   
   return new_table;
end

function X:TableHasKey(TABLE,NAME)
   for key,_ in pairs(table) do
      if key == NAME then return true; end
   end
   
   return false;
end

----------------------------------------

function X:IsRecipeTooltip()
    
end