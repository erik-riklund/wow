
-- X by Ghuul (2023)

local _, X = ...

local UseContainerItem = C_Container.UseContainerItem
local GetContainerNumSlots = C_Container.GetContainerNumSlots
local GetContainerItemLink = C_Container.GetContainerItemLink

X:SetDebug("merchant", false)

----------------------------------------

local V = CreateFrame("Frame", nil)
V:RegisterEvent("MERCHANT_SHOW")
V:RegisterEvent("MERCHANT_CLOSED")
V:RegisterEvent("PLAYER_LOGIN")

----------------------------------------

V:SetScript("OnEvent", function(self,EVENT)
   if EVENT == "PLAYER_LOGIN" then
      self:Hide()
   end
   
   if X:IsModuleActive("merchant") then
      if EVENT == "MERCHANT_SHOW" then
         if CanMerchantRepair() then RepairAllItems() end
         self.open = true
         self:ProcessBags()
      end
      
      if EVENT == "MERCHANT_CLOSED" then
         if self.open == true then
            self.open = false
            self:LearnCustomSales()
         end
      end
   end
end)

----------------------------------------

function V:ProcessBags()
   self.ignored = {
        "Conqueror's Mark of Sanctification",
        "Healthstone",
        "Nat Pagle's Extreme Angler FC-5000",
      "Protector's Mark of Sanctification",
        "Vanquisher's Mark of Sanctification",
        "Weather-Beaten Fishing Hat",
      }
   
   self.sales_list = {
      ["junk"] = {},
      ["gear"] = {},
      ["custom"] = {}
      }
   
   self.learned = X:GetV("merchant/learned", true) or {}
   
   for bag = 0,4 do
      for s = 1, GetContainerNumSlots(bag) do
         local item = GetContainerItemLink(bag,s)
         if item then
            item = X:GetItemInfo(item)
            if not tContains(self.ignored,item.name) then
               if tContains(self.learned,item.name) then self:RegisterItem("custom",bag,s) end
               if item.quality == 0 and item.sellprice > 0 then self:RegisterItem("junk",bag,s) end
               if X:GetPlayerLevel() > 60 and (item.type == "Armor" or item.type == "Weapon") then
                  if item.bindtype == 1 and item.expacID < GetServerExpansionLevel() and (item.quality == 3 or item.quality == 4) then
                     if #self.sales_list["gear"] < 12 then self:RegisterItem("gear",bag,s) end
                  end
               end
            end
         end
      end
   end
   
   self:Handler()
end

function V:RegisterItem(LABEL,BAG,SLOT)
   tinsert(self.sales_list[LABEL],{b=BAG,s=SLOT})
end

----------------------------------------

function V:Handler()
   local segment = "junk"
   if #self.sales_list[segment] == 0 then segment = "custom" end
   if #self.sales_list[segment] == 0 then segment = "gear" end
   
   if #self.sales_list[segment] == 0 then
      self:LogInventory()
      return;
   else
      self:SellItem(self.sales_list[segment][1].b,self.sales_list[segment][1].s)
      tremove(self.sales_list[segment], 1)
        
        C_Timer.After(.1, function() self:Handler() end);
   end
end

function V:SellItem(BAG,SLOT)
   if CursorHasItem() then ClearCursor(); end
   UseContainerItem(BAG,SLOT)
end

----------------------------------------

function V:LogInventory()
   self.inventory = {}
   
   for bag = 0,4 do
      for s = 1, GetContainerNumSlots(bag) do
         local item = GetContainerItemLink(bag,s)
         if item then
            item = X:GetItemInfo(item)
            if item.qualitytier then
               item.name = strjoin(":",item.name,item.qualitytier)
            end
            self.inventory[strjoin(".",bag,s)] = item
         end
      end
   end
end

function V:LearnCustomSales()
   self.saleslog = X:GetV("merchant/saleslog", true) or {}
   
   for bag = 0,4 do
      for s = 1, GetContainerNumSlots(bag) do
         if not GetContainerItemLink(bag,s) then
            local slot = strjoin(".",bag,s)
            if self.inventory[slot] then
               local item = self.inventory[slot]
               
               if not tContains(self.learned,item.name) and not tContains(self.ignored,item.name) then
                  if not (item.bindtype == 1 and item.expacID == GetServerExpansionLevel()) and item.quality > 0 and item.subtype ~= 'Cooking' then
                     self.saleslog[item.name] = (self.saleslog[item.name] or 0) + 1
                     
                     if self.saleslog[item.name] >= 5 then
                        tinsert(self.learned, item.name)
                        print("[merchant] "..item.link.." will be sold automatically from now on.")
                     end
                  end
               end
            end
         end
      end
   end
   
   local L = {}
   for name,count in pairs(self.saleslog) do
      if count < 5 then L[name] = count end
   end
   
   self.saleslog = L;
   X:SetV("merchant/learned", self.learned, true);
   X:SetV("merchant/saleslog", self.saleslog, true);
end

----------------------------------------

function X_InitiateMerhant()
    if V.open then V:ProcessBags(); end
end