
-- X by Ghuul (2023)

local _, X = ...
local T = CreateFrame('Frame', nil)

X:SetDebug('tooltip', false)

----------------------------------------

function TooltipHandler(TOOLTIP)
    if TOOLTIP:GetName() == 'GameTooltip' then
        if X:IsModuleActive('tooltip') then
            T.Lines = {}
            if TOOLTIP:GetItem() then T:Item(TOOLTIP) end
            if TOOLTIP:GetUnit() then T:Unit(TOOLTIP) end
            
            T:Generate(TOOLTIP)
        end
    end
end

----------------------------------------

function T:Item(TOOLTIP)
    local IGNORED = {
        'Artisan\'s Mettle',
        'Dragon Shard of Knowledge',
        'Enchanting Vellum',
        'Highborne Scroll',
        'Primal Chaos',
        'Restored Artifact',
        'Spark of Ingenuity',
        'Titan Training Matrix III',
        }
    
    local RECIPES = {
        'Design','Formula','Pattern','Plans','Recipe','Schematic','Technique'
        }
    
    local ITEM = X:GetItemInfo(select(2,TOOLTIP:GetItem()))
    if not tContains({'Armor','Weapon','Tradeskill'}, ITEM.type) or ITEM.quality == 0  or tContains(IGNORED, ITEM.name) then return; end
    
    local PREFIX = string.match(_G[TOOLTIP:GetName().."TextLeft1"]:GetText(), '^([A-Z][a-z]+):');
    if PREFIX ~= nil then
        if tContains(RECIPES, PREFIX) then return; end
    end
    
    self:AddLine(strjoin(' / ', ITEM.type,ITEM.subtype),'default', ITEM.expacname,'white')
end

----------------------------------------

function T:Unit(TOOLTIP)
    local UNIT = {
        name = TOOLTIP:GetUnit(),
        GUID = UnitGUID('mouseover'),
        isFriendly = UnitIsFriend('player','mouseover'),
        isDead = UnitIsDead('mouseover'),
        inCombat = UnitAffectingCombat('mouseover')
        }
    
    if UNIT.GUID then
        UNIT.type = strsplit('-',UNIT.GUID)
        if UNIT.type ~= 'Player' and UNIT.Type ~= 'Pet' and not UNIT.isFriendly and
            not (UnitAffectingCombat('player') and UNIT.inCombat) then
            
            if not UNIT.isDead then
                T:CreateUnitTooltip('Other','Possible drop  ', UNIT)
                T:CreateUnitTooltip('Pets','Possible companion (rare)', UNIT)
                T:CreateUnitTooltip('Mount','Possible mount (rare)', UNIT)
            end
            
            if X:PlayerHasProfession('Skinning') then
                T:CreateUnitTooltip('Skinning','Skinnable', UNIT) 
            end
            
            if X:PlayerHasProfession('Mining') then
                T:CreateUnitTooltip('Mining','Can be mined', UNIT)
            end
        end
    end
end

----------------------------------------

function T:CreateUnitTooltip(TAG,LABEL,UNIT)
    local REAGENT = {}
    
    REAGENT.P = TooltipDB:GetCachedReagent('Creatures',TAG,UNIT)
    REAGENT.R = TooltipDB:GetCachedReagent('Items',TAG,UNIT)
    
    if REAGENT.R and TAG == 'Mount' then
        local MOUNT_NAME = strsplit(':', REAGENT.R[1])
        if not X:PlayerHasMount(MOUNT_NAME) then
            T:CreateReagentLines(LABEL,REAGENT)
        end
    else
        if REAGENT.P then T:CreateCreatureLines(TAG,LABEL,UNIT,REAGENT) end
        if not REAGENT.P and REAGENT.R then T:CreateReagentLines(LABEL,REAGENT) end
    end
end

----------------------------------------

function T:CreateCreatureLines(TAG,LABEL,UNIT,REAGENT)
    if UNIT.isDead then LABEL = 'Reagents' end
    self:AddLine(LABEL,'default', REAGENT.P,'white')
    if REAGENT.R then T:CreateReagentLines('        ',REAGENT) end
end

----------------------------------------

function T:CreateReagentLines(LABEL,REAGENT)
    local REAGENTS = self:SortReagents(REAGENT.R)
    
    local quality_count = 0;
    local current_quality = -1;
    local reagent_lines = {};
    
    for i = 1, #REAGENTS do
        local reagent_name,reagent_quality = strsplit(':',REAGENTS[i]);
        
        if current_quality ~= reagent_quality then
            current_quality = reagent_quality;
            quality_count = quality_count + 1;
        end
        
        reagent_lines[quality_count] = reagent_lines[quality_count] or {};
        tinsert(reagent_lines[quality_count], REAGENTS[i]);
    end
    
    for q = 1, #reagent_lines do
        local reagent_stack = '';
        local last_quality;
        
        for r = 1, #reagent_lines[q] do
            local reagent_name,reagent_quality = strsplit(':',reagent_lines[q][r]);
            last_quality = reagent_quality;
            reagent_stack = reagent_stack .. reagent_name;
            
            if r < #reagent_lines[q] then
                reagent_stack = reagent_stack .. ', ';
            end
        end
        
        self:AddLine(LABEL,'default',reagent_stack,{GetItemQualityColor(last_quality)});
        LABEL = '               ';
    end
end

----------------------------------------

function T:SortReagents(REAGENTS)
    table.sort(REAGENTS, function(a,b)
            local aN,aQ = strsplit(':', a)
            local aS = strjoin(':',(4-aQ),aN)
            local bN,bQ = strsplit(':', b)
            local bS = strjoin(':',(4-bQ),bN)
            
            return aS < bS
        end)
    
    return REAGENTS
end

----------------------------------------

function T:AddLine(TEXT_L,COLOR_L,TEXT_R,COLOR_R)
    COLOR_L = COLOR_L or 'default'
    TEXT_R = TEXT_R or nil
    COLOR_R = COLOR_R or nil
    
    tinsert(T.Lines, {['TEXT_L'] = TEXT_L, ['COLOR_L'] = COLOR_L, ['TEXT_R'] = TEXT_R, ['COLOR_R'] = COLOR_R})
end

function T:Generate(TOOLTIP)
    if #T.Lines > 0 then TOOLTIP:AddLine(' ') end
    for i = 1, #T.Lines do
        if T.Lines[i]['TEXT_R'] == nil then
            local R,G,B = X:GetColor(T.Lines[i]['COLOR_L'])
            TOOLTIP:AddLine(T.Lines[i]['TEXT_L'], R,G,B)
        else
            local LR,LG,LB = X:GetColor(T.Lines[i]['COLOR_L'])
            local RR,RG,RB = X:GetColor(T.Lines[i]['COLOR_R'])
            TOOLTIP:AddDoubleLine(T.Lines[i]['TEXT_L'],T.Lines[i]['TEXT_R'], LR,LG,LB, RR,RG,RB)
        end
    end
end

----------------------------------------

TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, TooltipHandler)
TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, TooltipHandler)