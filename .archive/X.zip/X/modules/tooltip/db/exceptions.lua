
-- X by Ghuul (2023)

local _, X = ...

X.TooltipCollisions = {
   'Ancient Core Hound',
   'Crazed Owlbeast',
   'Darkshore Stag',
   'Diemetradon',
   'Elder Diemetradon',
   'Highland Strider',
   'Lava Elemental',
   'Primal Lava Elemental',
   'Stone Guardian',
   'Thunderhead',
   'Vicious Black Bear',
   'Young Diemetradon'
}