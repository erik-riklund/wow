﻿
-- X by Ghuul (2023)


TooltipDB.Items['Mount']['Chewed Reins of the Callow Flayedwing:4'] = {
   'Captive Skyripper',
   'Chosen Flayedwing',
   'Diseased Galescreamer',
   'Ferocious Nestkeeper',
   'Flayedwing Fleshripper',
   'Flayedwing Matriarch',
   'Flayedwing Screamer',
   'Galescreamer Elder',
   'Galescreamer Pup',
   'Gristlebeak',
   'Neonate Bonetooth',
   'Ravenous Galescreamer',
   'Satiated Sawtooth',
}

TooltipDB.Items['Mount']['Gnawed Reins of the Battle-Bound Warhound:4'] = {
   'Azmogal',
   'Devmorta',
   'Mistress Dyrax',
   'Ti\'or',
   'Unbreakable Urtz',
   'Xantuth the Blighted',
}