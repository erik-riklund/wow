
-- X by Ghuul (2023)

local _, X = ...

----------------------------------------

TooltipDB = {
    ["Creatures"] = {
        ["Mining"] = {},
        ["Skinning"] = {}
    },
    ["Items"] = {
        ["Mining"] = {},
        ["Skinning"] = {},
      ["Pets"] = {},
      ["Mount"] = {},
        ["Other"] = {}
    }
}

TooltipDB.v = 1.001

----------------------------------------

local T = CreateFrame("Frame", nil)

T:RegisterEvent("PLAYER_LOGIN")
T:SetScript("OnEvent", function(self)
   if X:IsModuleActive("tooltip") then
      local V = X:GetV("TooltipDB.v") or 0
      if V < TooltipDB.v or TooltipDB.v == 0 then
         TooltipDB:BuildCache(TooltipDB.v)
         X:SetV("TooltipDB.v", TooltipDB.v)
      end
   end
   
   wipe(TooltipDB.Creatures)
   wipe(TooltipDB.Items)
   
   if not X:IsModuleActive("tooltip") then
      X:SetV("TooltipDB", nil)
   end
end)

----------------------------------------

function TooltipDB:BuildCache(v)
   TooltipDB.CACHE = {
      ["Creatures"] = {
         ["Mining"] = {},
         ["Skinning"] = {}
      },
      ["Items"] = {
         ["Mining"] = {},
         ["Skinning"] = {},
         ["Pets"] = {},
         ["Mount"] = {},
         ["Other"] = {}
      }}
   
   local LABELS = {"Creatures","Items"}
   
   for l = 1, #LABELS do
      local LABEL = LABELS[l]
      for TAG,REAGENTS in pairs(TooltipDB[LABEL]) do
         for REAGENT_NAME,CREATURES in pairs(REAGENTS) do
            for i = 1, #CREATURES do
               TooltipDB:CacheReagent(LABEL,TAG,CREATURES[i],REAGENT_NAME)
            end
         end
      end
   end
   
   X:SetV("TooltipDB", TooltipDB.CACHE)
   if v == 0 then print ("TooltipDB: Cache updated (forced).")
   else print("TooltipDB: Cache updated to version ".. v ..".") end
end

----------------------------------------

function TooltipDB:CacheReagent(LABEL,TAG,CREATURE,ITEM)
   if LABEL == "Items" then
      if not TooltipDB.CACHE[LABEL][TAG][CREATURE] then
         TooltipDB.CACHE[LABEL][TAG][CREATURE] = {} end
      tinsert(TooltipDB.CACHE[LABEL][TAG][CREATURE],ITEM)
   else
      TooltipDB.CACHE[LABEL][TAG][CREATURE] = ITEM
   end
end

----------------------------------------

function TooltipDB:GetCachedReagent(LABEL,TAG,UNIT)
   local CACHE = X:GetV("TooltipDB")
   
   if CACHE[LABEL] then
      if CACHE[LABEL][TAG] then
         if tContains(X.TooltipCollisions,UNIT.name) then
            local CID = select(6,strsplit("-",UNIT.GUID))
            local CNAME = strjoin(":",UNIT.name,CID)
            return CACHE[LABEL][TAG][CNAME]
         else
            return CACHE[LABEL][TAG][UNIT.name]
         end
      end
   end
end