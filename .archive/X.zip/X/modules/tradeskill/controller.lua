
-- X by Ghuul (2023)

-- This module remember the state of settings and tabs in the profession window, and will
-- reset them to the state they were to avoid having to fold/unfold everything repeatedly.

local P = {};
local _, X = ...

--local PF = _G['ProfessionsFrame'];

X:SetDebug('tradeskill', false);

-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

