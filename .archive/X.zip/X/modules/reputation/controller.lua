
-- X by Ghuul (2023)

local _, X = ... local R = {}
local RF = _G["ReputationFrame"]

X:SetDebug("reputation", false)

----------------------------------------

function R:UpdateFactions()
   local index = X:GetV("reputation/state", true) or {}
   
   for i = 1, GetNumFactions() do
      local faction = X:GetFactionInfo(i)
      if faction.isHeader then
         if faction.ID ~= nil then
            index[faction.ID] = faction.isCollapsed
         end
      end
   end
   
   X:SetV("reputation/state",index,true)
   return index
end

function R:FactionExists(ID)
   local index = X:GetV("reputation/state", true) or {}
   for factionID,_ in pairs(index) do
      if factionID == ID then return true end
   end
   return false
end

function R:ToggleFactions(INIT)
   INIT = INIT or false
   
   self.handled = self.handled or {}
   if INIT == true then self.handled = {}; end
   local factions = X:GetV("reputation/state", true) or nil
   if factions == nil then factions = self:UpdateFactions() end
   
   for i = 1, GetNumFactions() do
      local faction = X:GetFactionInfo(i)
      if faction.ID ~= nil then
         if faction.isHeader and self:FactionExists(faction.ID) then
            if faction.isCollapsed ~= factions[faction.ID] then
               if not tContains(self.handled,faction.ID) then
                  if factions[faction.ID] == true then
                     CollapseFactionHeader(i)
                     X:Debug("reputation", "Collapsing header ["..faction.name.."]")
                  end
                  if factions[faction.ID] == false then
                     ExpandFactionHeader(i)
                     X:Debug("reputation", "Expanding header ["..faction.name.."]")
                  end
                  
                  tinsert(self.handled,faction.ID)
                  self:ToggleFactions()
                  return
               end
            else
               tinsert(self.handled,faction.ID)
            end
         end
      end
   end
end

----------------------------------------

RF:HookScript("OnShow", function(self)
   if X:IsModuleActive("reputation") then
      self.updating = false
      self.factions = GetNumFactions()
      
      if X:GetV("reputation/init", true) == nil then
         X:SetV("reputation/init", true, true)
         R:UpdateFactions()
      end
      
      R:ToggleFactions(true)
   end
end)

RF:HookScript("OnUpdate", function(self,TIMER)
   if X:IsModuleActive("reputation") then
      if self.factions ~= GetNumFactions() and not self.updating then
         self.updating = true
         R:ToggleFactions()
         R:UpdateFactions()
         
         self.factions = GetNumFactions()
         self.updating = false
      end
   end
end)

RF:HookScript("OnHide", function(self)
   if X:IsModuleActive("reputation") then R:UpdateFactions() end
end)