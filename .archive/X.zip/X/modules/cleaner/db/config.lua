
-- X by Ghuul (2023)

local _, X = ...

local DEFAULT_ORDER = 6
local ENUM_ORDER_HEARTHSTONE = 0
local ENUM_ORDER_PROFESSION = 1
local ENUM_ORDER_RELICS = 2
local ENUM_ORDER_QUEST = DEFAULT_ORDER +4
local ENUM_ORDER_BOXES = DEFAULT_ORDER +5

Cleaner_CONFIG = {
   
   -- Reagents --
   
   -- Items that will be moved to the tradeskills bag:
   ['FORCE_REAGENTS'] = {
      'Deviate Fish'
   },
   
   
   -- The order in which reagents will be presented:
   ['TRADEGOODS.SORTORDER'] = {
      'Enchanting',
      'Elemental',
      'Metal & Stone',
      'Parts',
      'Jewelcrafting',
      'Leather',
      'Herb',
      'Inscription',
      'Cloth',
      'Cooking'
   },
   
   -- Items that will be  presented first in the segment:
   ['TRADEGOODS.STICKY'] = {
      'Artisan\'s Mettle',
      'Dragon Shard of Knowledge',
      'Primal Chaos',
      'Spark of Ingenuity',
      'Titan Training Matrix I',
      'Titan Training Matrix II',
      'Titan Training Matrix III',
   },
   
   -- Items that will be moved to the end of its type's category:
   ['TRADEGOODS.TAILS'] = {
      
      -- Classic
      'Black Vitriol',
      'Coarse Stone',
      'Deeprock Salt',
      'Dense Stone',
      'Heavy Stone',
      'Rough Stone',
      'Solid Stone',
      
      -- Dragonflight
      'Basilisk Eggs',
      'Burly Bear Haunch',
      'Bruffalon Flank',
      'Contoured Fowlfeather',
      'Hornswog Hunk',
      'Maybe Meat',
      'Mighty Mammoth Ribs',
      'Ribbed Mollusk Meat',
      'Salt Deposit',
   },
   
   -- Backpack --
   
   -- Items that will be moved to the backpack:
   ['FORCE_BACKPACK'] = {
      'Ancient Suramar Scroll',
      'Enchanting Vellum',
      'Highborne Scroll',
      'Restored Artifact'
   },
   
   -- Customized sorting for items in the backpack:
   ['BACKPACK_ORDER'] = {
      
      ['Dalaran Hearthstone'] = ENUM_ORDER_HEARTHSTONE,
      ['Garrison Hearthstone'] = ENUM_ORDER_HEARTHSTONE,
      ['Hearthstone'] = ENUM_ORDER_HEARTHSTONE,
      ['Uncrowned Insignia'] = ENUM_ORDER_HEARTHSTONE,
      
      ['Bright Baubles'] = ENUM_ORDER_PROFESSION,
      ['Enchanting Vellum'] = ENUM_ORDER_PROFESSION,
      ['Glow Worm'] = ENUM_ORDER_PROFESSION,
      ['Nat Pagle\'s Extreme Angler FC-5000'] = ENUM_ORDER_PROFESSION,
      ['Oversized Bobber'] = ENUM_ORDER_PROFESSION,
      ['Runed Copper Rod'] = ENUM_ORDER_PROFESSION,
      ['Weather-Beaten Fishing Hat'] = ENUM_ORDER_PROFESSION,
      
      ['Ancient Suramar Scroll'] = ENUM_ORDER_PROFESSION,
      ['Highborne Scroll'] = ENUM_ORDER_PROFESSION,
      ['Restored Artifact'] = ENUM_ORDER_PROFESSION,
      
      ['Centaur Hunting Trophy'] = ENUM_ORDER_RELICS,
      ['Coin of Ancestry'] = ENUM_ORDER_RELICS,
      ['Copper Coin of the Isles'] = ENUM_ORDER_RELICS,
      ['Dragon Isles Artifact'] = ENUM_ORDER_RELICS,
      ['Dreamsurge Coalescence'] = ENUM_ORDER_RELICS,
      ['Elder\'s Moonstone'] = ENUM_ORDER_RELICS,
      ['Essence of the Storm'] = ENUM_ORDER_RELICS,
      ['Gold Coin of the Isles'] = ENUM_ORDER_RELICS,
      ['Lost Razorwing Egg'] = ENUM_ORDER_RELICS,
      ['Rumble Foil'] = ENUM_ORDER_RELICS,
      ['Sacred Tuskarr Totem'] = ENUM_ORDER_RELICS,
      ['Silver Coin of the Isles'] = ENUM_ORDER_RELICS,
      ['Titan Relic'] = ENUM_ORDER_RELICS,
      ['Winterfall Spirit Beads'] = ENUM_ORDER_RELICS,
      ['Whelpling\'s Shadowflame Crest Fragment'] = ENUM_ORDER_RELICS,
      
      ['Bag of Shiny Things'] = ENUM_ORDER_BOXES,
      ['Bounty of the Grove Wardens'] = ENUM_ORDER_BOXES,
      ['Dragon Racer\'s Purse'] = ENUM_ORDER_BOXES,
      ['Fallen Adventurer\'s Cache'] = ENUM_ORDER_BOXES,
      ['Glowing Primalist Cache'] = ENUM_ORDER_BOXES,
      ['Iron Bound Trunk'] = ENUM_ORDER_BOXES,
      ['Korthian Armaments'] = ENUM_ORDER_BOXES,
      ['Lucky Red Envelope'] = ENUM_ORDER_BOXES,
      ['Obsidian Strongbox'] = ENUM_ORDER_BOXES,
      ['Sealed Crate'] = ENUM_ORDER_BOXES,
      ['Slimy Bag'] = ENUM_ORDER_BOXES,
      ['Tribute of the Ascended'] = ENUM_ORDER_BOXES,
      ['Tribute of the Duty-Bound'] = ENUM_ORDER_BOXES,
      ['Tribute of the Wild Hunt'] = ENUM_ORDER_BOXES,
      ['Valdrakken Treasures'] = ENUM_ORDER_BOXES,
      
      ['Healthstone'] = ENUM_ORDER_QUEST,
      ['Key Fragments'] = ENUM_ORDER_QUEST,
      ['Key Framing'] = ENUM_ORDER_QUEST,
   }
}