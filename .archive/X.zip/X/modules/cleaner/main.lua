
-- X by Ghuul (2023)

local _, X = ...
X:SetDebug('cleaner', false)

local C = CreateFrame('Frame','X_Cleaner'); C:Hide();

local PickupContainerItem = C_Container.PickupContainerItem
local GetContainerItemLink = C_Container.GetContainerItemLink
local GetContainerItemInfo = C_Container.GetContainerItemInfo
local GetContainerNumSlots = C_Container.GetContainerNumSlots

----------------------------------------
-- initiate the process:

function C:Initiate()
   if X:IsModuleActive('cleaner') then
      if not self:IsShown() then
         X:Debug('cleaner','Starting up');
         
            self:Show();
         self:ProcessBags();
      end
   end
end

----------------------------------------
-- process bags and analyze items:

function C:ProcessBags()
    X:Debug('cleaner','Processing bags');
   
   self.segments = {
      ['misc'] = {0,1},
      ['tradeskill'] = {2,3},
      ['junk'] = {4}};
   
   self.sorted = {};
   self.unsorted = {};
   self.sorted_items = 0;
    
	self.delay = .25;
   
   for label,bags in pairs(self.segments) do
      self.unsorted[label] = self.unsorted[label] or {}
      
      local force_junk = X:GetV('merchant/learned', true);
      local force_backpack = self:GetCFG('FORCE_BACKPACK');
      local force_reagents = self:GetCFG('FORCE_REAGENTS');
      
      for i = 1, #bags do
         local bag = bags[i];
         
         for s = 1, GetContainerNumSlots(bag) do
            local segment = label;
            local link = GetContainerItemLink(bag,s);
            
            if link then
					local xpac = 9;
               local item = X:GetItemInfo(link);

					if item.expacID then xpac = 9 - item.expacID; end
               
               if item.type == 'Tradeskill' and segment ~= 'tradeskill' then segment = 'tradeskill'; end
               if item.quality == 0 and segment ~= 'junk' then segment = 'junk'; end
               if item.type ~= 'Tradeskill' and item.quality > 0 then segment = 'misc'; end
               if tContains(force_junk,item.name) then segment = 'junk'; end
               if tContains(force_backpack,item.name) then segment = 'misc'; end
               if tContains(force_reagents,item.name) then segment = 'tradeskill'; end
                    
                    local PREFIX = string.match(item.name,'^([A-Z][a-z]+):');
                    if PREFIX ~= nil and tContains({'Design','Formula','Pattern','Plans','Recipe','Schematic','Technique'}, PREFIX) then
                        segment = 'misc';
                        item.type = 'Tradeskill';
                        item.subtype = 'Recipe';
                    end
                    
               if segment ~= 'tradeskill' then xpac = 0; end
               
               self.unsorted[segment] = self.unsorted[segment] or {};
               self.unsorted[segment][xpac] = self.unsorted[segment][xpac] or {};
               
               local q = GetContainerItemInfo(bag,s); item.count = q['stackCount'];
               tinsert(self.unsorted[segment][xpac],{['item'] = item,['slot'] = self:GetSlotData(bag,s)});
            end
         end
      end
   end
   
   self:SortProcessedItems();
end

----------------------------------------
-- execute the sorting of each segment:

function C:SortProcessedItems()
   self.sorted = {}
   for _,label in pairs({'junk','tradeskill','misc'}) do
      self.sorted[label] = {}
        
      if label == 'misc' then self:SortBackpack();
      elseif label == 'tradeskill' then self:SortReagents();
      elseif label == 'junk' then self:SortJunk(); end
   end
   
   if self.sorted_items > 0 then
        X:Debug('cleaner','Executing sorting process');
        
        self:MoveNextItem();
    else
        X:Debug('cleaner','Nothing to do, shutting down');
        self:Hide();
        ClearCursor();
    end
end

----------------------------------------
-- sort backpack content:

function C:SortBackpack()
   local sorting_table = {}
   
   local DEFAULT_ORDER = 6;
   local ENUM_ORDER_QUEST = DEFAULT_ORDER +4;
    local ENUM_ORDER_CONSUMABLE = DEFAULT_ORDER -3;
    local ENUM_ORDER_RECIPES = DEFAULT_ORDER -2
    local ENUM_ORDER_EQUIPMENT = DEFAULT_ORDER -1;
   
    local order_list = self:GetCFG('BACKPACK_ORDER');
   
    for e = 0, GetServerExpansionLevel() do
      if self.unsorted['misc'][e] then
         for i = 1, #self.unsorted['misc'][e] do
            local misc = self.unsorted['misc'][e][i];
                local item = misc.item;
                
            local order = order_list[item.name] or DEFAULT_ORDER;
            
            if item.type == 'Consumable' and not order_list[item.name] then order = ENUM_ORDER_CONSUMABLE; end
            if item.type == 'Quest' and not order_list[item.name] then order = ENUM_ORDER_QUEST; end
                if item.type == 'Tradeskill' and item.subtype == 'Recipe' and not order_list[item.name] then order = ENUM_ORDER_RECIPES; end
            
            if (item.type == 'Armor' or item.type == 'Weapon') and not order_list[item.name] then
               item.name = strjoin(':',item.type,item.subtype,1000-item.ilvl,item.name);
               order = ENUM_ORDER_EQUIPMENT;
            end
            
            if item.qualitytier then
               item.name = strjoin('/',item.name,X:NumToChar(3-item.qualitytier));
            end
            
            tinsert(sorting_table,{['info'] = strjoin('/',X:NumToChar(order),9-item.quality,
               item.name,(1000-item.count)),['slot'] = misc.slot,['item'] = item});
         end
      end
   end
   
   table.sort(sorting_table, function(a,b)
      return string.upper(a.info) < string.upper(b.info);
   end)
   
   self:BuildMoveTable('misc',{[0]=sorting_table});
end

----------------------------------------
-- sort tradeskill reagents:

function C:SortReagents()
   local sorting_table = {};
   
   if not self.sort_order then
      self.sort_order = {};
      
      local sorting_n = 1;
      local sort_config = self:GetCFG('TRADEGOODS.SORTORDER');
      
      for i = 1, #sort_config do
         self.sort_order[sort_config[i]] = sorting_n;
         sorting_n = sorting_n +1;
      end
      
      self.sort_order['DEFAULT'] = sorting_n;
   end
   
   local sticky_items = self:GetCFG('TRADEGOODS.STICKY');
   local tail_items = self:GetCFG('TRADEGOODS.TAILS');
   
   for e = 0, GetServerExpansionLevel() do
      if self.unsorted['tradeskill'][e] then
         sorting_table[e] = {};
         
         for i = 1, #self.unsorted['tradeskill'][e] do
            local reagent = self.unsorted['tradeskill'][e][i];
                local item = reagent.item;
            local order = self.sort_order[item.subtype] or self.sort_order['DEFAULT'];
            
            if item.qualitytier then
               item.name = strjoin('/',item.name,X:NumToChar(3-item.qualitytier)); end
            
            if tContains(sticky_items,item.name) then order = 0; end
            if tContains(tail_items,item.name) then item.quality = 0; end
            
            tinsert(sorting_table[e],{['info'] = strjoin('/',X:NumToChar(order),X:NumToChar(9-item.quality),
               item.name,1000-item.count),['slot']=reagent['slot'],['item']=item});
         end
         
         table.sort(sorting_table[e], function(a,b)
            return string.upper(a.info) < string.upper(b.info);
         end)
      end
   end
   
   self:BuildMoveTable('tradeskill',sorting_table);
end

----------------------------------------
-- sort items in the junk segment:

function C:SortJunk()
   local sorting_table = {};
    
   if self.unsorted['junk'][0] then
      for i = 1, #self.unsorted['junk'][0] do
         local junk = self.unsorted['junk'][0][i];
            self.unsorted['junk'][0][i]['item']['name'] = strjoin('', self.unsorted['junk'][0][i]['item']['name']);
         tinsert(sorting_table,{['value']=junk.item.sellprice*junk.item.count,['slot']=junk.slot,['item']=junk.item});
      end
      
      table.sort(sorting_table, function(a,b)
            if a.value == b.value then
                    return a.item.name < b.item.name;
            else
               return a.value > b.value;
            end
         end)
      
      self:BuildMoveTable('junk',{[0]=sorting_table});
   end
end

----------------------------------------
-- generate the sorting list for a segment:

function C:BuildMoveTable(LABEL,TABLE)
   local bag = self.segments[LABEL][1];
   local bag_size = GetContainerNumSlots(bag);
   local current_slot = 1;

   -- reverse junk?
   if LABEL == 'junk' then
      current_slot = bag_size;
   end
   --
   
   for e = 0, GetServerExpansionLevel() do
      if TABLE[e] then
         for i = 1, #TABLE[e] do
            if current_slot > bag_size and bag < self.segments[LABEL][#self.segments[LABEL]] then
               bag = bag +1;
               bag_size = GetContainerNumSlots(bag);
               current_slot = 1;
            end
            
            local target = self:GetSlotData(bag,current_slot);
            if target ~= TABLE[e][i]['slot'] then
               tinsert(self.sorted[LABEL],{['C']=TABLE[e][i]['slot'],['D']=target,['item']={['name']=TABLE[e][i]['item']['name'],['count']=TABLE[e][i]['item']['count']}});
               self.sorted_items = self.sorted_items +1;
            end
            
            if LABEL == 'junk' then
               current_slot = current_slot -1;
            else
               current_slot = current_slot +1;
            end
         end
      end
   end
end

----------------------------------------
--    sorting timer functions
----------------------------------------

-- triggered onShow, starting the timer:

C:SetScript('OnShow', function(self) self.timer = 0; end);

-- updates the timer and stops the application if it runs too long:

C:SetScript('OnUpdate', function(self,ELAPSED)
   self.timer = self.timer+ELAPSED;
   if self.timer >= 45 then
      X:Debug('cleaner','Process ran for too long, forcing stop'); self:Hide();
   end
end);

-- triggered onHide, printing the result of the process timer:

C:SetScript('OnHide', function(self)
   self.timer = string.format('%.2f',self.timer);
    if CursorHasItem() then ClearCursor(); end
    print('X: Sorting completed in '..self.timer..' sec, shutting down.');
end);

----------------------------------------
--    sorting management functions
----------------------------------------

-- find the next misplaced item that should be moved:

function C:GetNextItem()
    for _,label in pairs({'junk','tradeskill','misc'}) do
        for i = #self.sorted[label], 1,-1 do
            if self.sorted[label][i]['C'] ~= self.sorted[label][i]['D'] then
                return label, i;
            end
        end
    end
end

-- track the location of items that swap places:

function C:ItemSwap(SEGMENT,INDEX)
   for _,LABEL in pairs({'junk','tradeskill','misc'}) do
      for i = 1, #self.sorted[LABEL] do
         if self.sorted[LABEL][i]['C'] == self.sorted[SEGMENT][INDEX]['D'] then
            self.sorted[LABEL][i]['C'] = self.sorted[SEGMENT][INDEX]['C']; return;
         end
      end
   end
end

-- moves the specified item to it's destination:

function C:PickupItem(SEGMENT,INDEX)
   local current_bag,current_slot = self:GetPosData(self.sorted[SEGMENT][INDEX]['C']);
   local target_bag,target_slot = self:GetPosData(self.sorted[SEGMENT][INDEX]['D']);
   
   repeat
        local current_lock = select(3,GetContainerItemInfo(current_bag,current_slot));
        local target_lock = select(3,GetContainerItemInfo(target_bag,target_slot));
    until not current_lock and not target_lock
    
    --if CursorHasItem() then ClearCursor(); end
    if CursorHasItem() then C_Timer.After(self.delay, function() ClearCursor(); self:PickupItem(SEGMENT,INDEX); end); end
    PickupContainerItem(current_bag,current_slot);
    PickupContainerItem(target_bag,target_slot);
    
    --repeat
    --    local current_lock = select(3,GetContainerItemInfo(current_bag,current_slot));
    --    local target_lock = select(3,GetContainerItemInfo(target_bag,target_slot));
    --until not current_lock and not target_lock
    
    local delay = self.delay*1.5;
    if not CursorHasItem() then delay = self.delay; end
    
    C_Timer.After(delay, function()
        self.sorted[SEGMENT][INDEX]['C'] = self.sorted[SEGMENT][INDEX]['D'];
        self:MoveNextItem();
    end);
end

-- sorting handler:

function C:MoveNextItem()
    local segment,index = self:GetNextItem();
    if not segment then self:Hide(); return end
    
    self:ItemSwap(segment,index);
    C_Timer.After(self.delay*.5, function()
        self:PickupItem(segment,index);
    end);
end

----------------------------------------
--     slot management functions
----------------------------------------

-- get a string representation of a bagslot:

function C:GetSlotData(bag,slot)
   return strjoin('.',bag,slot); end

-- break down a bagslot string into useable pieces:

function C:GetPosData(SOURCE)
   local bag,slot = strsplit('.',SOURCE);
   return tonumber(bag), tonumber(slot);
end

----------------------------------------
-- get configuration value:

function C:GetCFG(LABEL)
   return Cleaner_CONFIG[LABEL]; end

----------------------------------------

function X_InitiateCleaner() C:Initiate() end

SLASH_CLEANER1 = '/cleaner'
SlashCmdList['CLEANER'] = function() X_InitiateCleaner() end