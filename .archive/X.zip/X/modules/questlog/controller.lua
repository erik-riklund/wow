
-- X by Ghuul (2023)

local _, X = ...

local Q = {}
local QF = _G['QuestMapFrame']

X:SetDebug('questlog',false)

local GetNumQuestLogEntries = C_QuestLog.GetNumQuestLogEntries

----------------------------------------

function Q:UpdateHeaderStates()
   local quests = {}
   
   for i = 1, GetNumQuestLogEntries() do
      local quest = C_QuestLog.GetInfo(i);
      if quest.isHeader and not quest.isHidden and quest.title ~= 'World Quest' then
         quests[quest.title] = (quest.isCollapsed == true);
      end
   end
   
   X:SetV('questlog/state',quests,true)
   return quests
end

function Q:HeaderIsRegistered(TITLE)
   quests = X:GetV('questlog/state', true) or {}
   for name,status in pairs(quests) do
      if name == TITLE then return true end
   end
   
   return false
end

function Q:ToggleHeaders()
   local quests = X:GetV('questlog/state',true) or {}
   
   CollapseQuestHeader(0);
   X:Debug('questlog','Collapsing all headers');
   
   for i = 1, GetNumQuestLogEntries() do
      local quest = C_QuestLog.GetInfo(i);
      
      if quest.isHeader and not quest.isHidden then
         if self:HeaderIsRegistered(quest.title) and quests[quest.title] == false then
            ExpandQuestHeader(i);
            X:Debug('questlog', 'Expanding header '..quest.title..' [index '..i..']');
         else CollapseQuestHeader(i); end
      end
   end
   
   QF.delay_elapsed = false
end

----------------------------------------

QF:HookScript('OnShow', function(self)
   if X:IsModuleActive('questlog') then
      if X:GetV('questlog/init',true) == nil then
         X:SetV('questlog/init',true,true)
         Q:UpdateHeaderStates()
      end
      
      X:Debug('questlog','Window opened');
      
      self.elapsed = 0;
      self.delay_elapsed = true;
      Q:ToggleHeaders();
   end
end)

QF:HookScript('OnUpdate', function(self,T)
   if X:IsModuleActive('questlog') then
      self.elapsed = self.elapsed+T
      if self.elapsed >= 0.2 and self.delay_elapsed == false then
         Q:UpdateHeaderStates();
         self.elapsed = 0;
      end
   end
end)