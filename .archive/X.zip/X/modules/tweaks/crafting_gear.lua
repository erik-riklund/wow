
-- X by Ghuul (2023)

local _, X = ...

CF = CreateFrame('Frame','X_NoCraftingGearVisuals');

CF:RegisterEvent('LOOT_OPENED');
CF:RegisterEvent('LOOT_CLOSED');

CF:SetScript('OnEvent', function(self,EVENT)
   if X_Tweaks['NoCraftingGearVisuals'] == false then
      self:UnregisterEvent('LOOT_OPENED');
      self:UnregisterEvent('LOOT_CLOSED');
      return;
   end
   
   if EVENT == 'LOOT_OPENED' then self.checkBuffs = true; end
   if EVENT == 'LOOT_CLOSED' and self.checkBuffs == true then
      for i = 1, 40 do
         if tContains({'Rockin\' Mining Gear','Dressed To Kill','Fishing For Attention'}, UnitBuff('player', i)) then CancelUnitBuff('player',i); end
         self.checkBuffs = false;
      end
   end
end);
