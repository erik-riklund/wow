
-- X by Ghuul (2023)

local _, X = ...
X:SetDebug('autoloot',false);

local L = CreateFrame('Frame','autoloot');

----------------------------------------

L:RegisterEvent('LOOT_READY');
L:RegisterEvent('LOOT_OPENED');

L:SetScript('OnEvent', function(self,EVENT)
   if X:IsModuleActive('autoloot') then
      if EVENT == 'LOOT_READY' then L:Process(); end
      if EVENT == 'LOOT_OPENED' then L:Loot(); end
   end
end)

----------------------------------------

function L:Process()
   self.slots = {}
   self.drops = GetNumLootItems();
   self.merchant_learned = X:GetV('merchant/learned', true) or {}
   
   for i = self.drops, 1,-1 do
      local slot_type = GetLootSlotType(i);
      local _,item_name,item_quantity,_,_,isLocked,isQuestItem = GetLootSlotInfo(i);
      
      if not isLocked then
         if slot_type == 2 and self:CheckCoins(item_name) then self:LootSlot(i); end
         if slot_type == 3 and self:CheckCurrency(item_name) then self:LootSlot(i); end
         if isQuestItem and self:CheckQuestItem(item_name,item_quantity) then self:LootSlot(i); end
         
         if slot_type == 1 then
            local item = X:GetItemInfo(GetLootSlotLink(i));
            
            if not self:ItemIsIgnored(item) then
               if self:ItemIsCustomLoot(item) or tContains(self.merchant_learned,item.name) then self:LootSlot(i);
               elseif item.quality == 0 and self:CheckJunk(item) then self:LootSlot(i);
               elseif IsFishingLoot() and self:CheckFish(item) then self:LootSlot(i);
               elseif not IsFishingLoot() and item.type == 'Tradeskill' and self:CheckReagent(item) then self:LootSlot(i);
               elseif (item.type == 'Armor' or item.type == 'Weapon') and self:CheckEquipment(item) then self:LootSlot(i); end
            end
         end
      end
   end
end

----------------------------------------

function L:LootSlot(i) tinsert(self.slots,i); end
function L:Loot() for i = 1, #self.slots do LootSlot(self.slots[i]); end end

----------------------------------------

function L:CheckCurrency(NAME)
   return tContains(X.Autoloot['currency'], NAME);
end

function L:CheckCoins(NAME)
   local cash = strsplit('\n',NAME);
   local amount, value = strsplit(' ',cash);
   
   return value ~= 'Gold' or (value == 'Gold' and tonumber(amount) < 50)
end

function L:CheckQuestItem(NAME,QUANTITY)
   return self.drops == 1 or QUANTITY > 1 or tContains(X.Autoloot['quests'],NAME);
end

----------------------------------------

function L:ItemIsIgnored(ITEM)
   return tContains(X.Autoloot['ignore'][ITEM.expacID],ITEM.name);
end

function L:ItemIsCustomLoot(ITEM)
   return tContains(X.Autoloot['custom'][ITEM.expacID],ITEM.name);
end

----------------------------------------

function L:CheckJunk(ITEM)
   --return not tContains({'Armor','Weapon'},ITEM.type) and (ITEM.sellprice > 0 and ITEM.sellprice < 100000)
    if tContains({'Armor','Weapon'}, ITEM.type) then
        if ITEM.equiploc == 'INVTYPE_CLOAK' or X:PlayerCanUseItem(ITEM) then
            return X:PlayerHasTransmog(ITEM);
        else
            return true;
        end
    else
        return ITEM.sellprice > 0 and ITEM.sellprice < 100000;
    end
end

function L:CheckFish(ITEM)
   return tContains(X.Autoloot['fish'],ITEM.name) or
      (ITEM.type == 'Tradeskill' and ITEM.subtype == 'Cooking')
end

function L:CheckReagent(ITEM)
   return (tContains({'Cloth','Herb','Leather','Metal & Stone'},ITEM.subtype) and ITEM.quality < 3)
      or (ITEM.subtype == 'Cooking' and ITEM.expacID < GetServerExpansionLevel())
end

----------------------------------------

function L:CheckEquipment(ITEM)
   if X:GetPlayerLevel() > 60 then
      if ITEM.bindtype == 1 and ITEM.expacID < GetServerExpansionLevel() then
         if ITEM.equiploc == 'INVTYPE_CLOAK' or X:PlayerCanUseItem(ITEM) then
            return X:PlayerHasTransmog(ITEM); else return true; end
      end
   end
   
   return false
end