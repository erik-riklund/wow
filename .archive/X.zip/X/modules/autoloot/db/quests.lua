
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot['quests'] = {
   'Arctic Char',
   'Azshara Snakehead',
   'Cooked Caviar',
   'Devoured Anima',
   'Fel Blood',
   'Fresh Fish Steak',
   'Hardened Walleye',
   'Korthian Repository',
   'Mawsworn Emblem',
   'Rugged Carapace',
   'Stormscale Spark',
   'Time-Lost Possession',
   'Toxic Puddlefish',
   'Undivided Hide',
   'Violet Perch'
}