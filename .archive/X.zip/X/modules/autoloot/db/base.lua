
-- X by Ghuul (2023)

local _, X = ...
X.Autoloot = {}

------------------------------------------------------------
X.Autoloot.ignore = {
   [0] = {}, -- Classic
   [1] = {}, -- Burning Crusade
   [2] = {}, -- Wrath of the Lich King
   [3] = {}, -- Cataclysm
   [4] = {}, -- Pandaria
   [5] = {}, -- Warlords of Draenor
   [6] = {}, -- Legion
   [7] = {}, -- Battle for Azeroth
   [8] = {}, -- Shadowlands
   [9] = {}  -- Dragonflight
}
------------------------------------------------------------
X.Autoloot.custom = {
   [0] = {}, -- Classic
   [1] = {}, -- Burning Crusade
   [2] = {}, -- Wrath of the Lich King
   [3] = {}, -- Cataclysm
   [4] = {}, -- Pandaria
   [5] = {}, -- Warlords of Draenor
   [6] = {}, -- Legion
   [7] = {}, -- Battle for Azeroth
   [8] = {}, -- Shadowlands
   [9] = {}  -- Dragonflight
}