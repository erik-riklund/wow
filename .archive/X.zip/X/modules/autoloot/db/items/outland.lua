
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[1] = {
   
   
}

X.Autoloot.ignore[1] = {
   
   'Fel Hide',
}