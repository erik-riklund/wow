
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[8] = {
   
   'Anima Gossamer',
   'Anima-Stained Glass Shards',
   'Bottle of Diluted Anima-Wine',
   'Concealed Sinvyr Flask',
   'Crumbling Stone Tablet',
   'Depleted Stoneborn Heart',
   'Engraved Glass Pane',
   'Gnawed Ancient Idol',
   'Infused Dendrite',
   'Lush Marrowroot',
   'Maldraxxi Armor Scraps',
   'Malleable Flesh',
   'Nascent Sporepod',
   'Novice Principles of Plaguistry',
   'Questionable Mawshrooms',
   'Relic Fragment',
   'Resonating Anima Mote',
   'Roster of the Forgotten',
   'Runic Diagram',
   'Sanctified Skylight Leaf',
   'Singed Soul Shackles',
   'Soulcatching Sludge',
   'Strangely Intricate Key',
   'Tenebrous Truffle',
   'Twilight Bark',
   'Unearthed Teleporter Sigil',
   'Unlabeled Culture Jars',
   'Vial of Mysterious Liquid',
   'Wafting Koricone',
   'Weeping Corpseshroom',
}

X.Autoloot.ignore[8] = {
   
   'Heavy Desolate Leather',
   'Lightless Silk'
}