
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[6] = {
   
   'Unbroken Claw',
   'Unbroken Tooth',
}

X.Autoloot.ignore[6] = {
   
   'Felhide',
   'Felwort',
   'Infernal Brimstone',
}