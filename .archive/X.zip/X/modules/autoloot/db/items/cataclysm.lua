
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[3] = {
   
   
}

X.Autoloot.ignore[3] = {
   
   
}