
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[2] = {
   
   
}

X.Autoloot.ignore[2] = {
   
   'Frost Lotus',
    'Nerubian Chitin'
}