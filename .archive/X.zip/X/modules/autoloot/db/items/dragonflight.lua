
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[9] = {
   
   'Blightshroom',
   'Claw Thistle Barbs',
   'Cuppressa Berries',
   'Dreamsurge Coalescence',
   'Everglow Nectar',
   'Exceptional Pelt',
   'Fangtooth Petals',
   'Fluorescent Fluid',
   'Gratona Seed',
   'Inferno Seeds',
   'Key Fragments',
   'Magenta Titian Extract',
   'Maybe Meat',
   'Milkweed Fibers',
   'Panthis Nectar',
   'River Bell Bulbs',
   'Salt Deposit',
   'Shattered Adamant Scales',
   'Thaldraszus Root',
   'Titian Extract',
   'Torn Resilient Leather Scraps',
   'Vine Flower Fibers',
   'White Bell Pigment',
   'Woolly Mountain Pelt'
}

X.Autoloot.ignore[9] = {
   
   'Cacophonous Thunderscale',
   'Contoured Fowlfeather',
   'Crystalspine Fur',
   'Fire-Infused Hide',
    'Frostbitten Wildercloth',
   'Pristine Vorquin Horn',
   'Rockfang Leather',
   'Salamanther Scales',
    'Singed Wildercloth',
   'Wildercloth',
   'Windsong Plumage'
}