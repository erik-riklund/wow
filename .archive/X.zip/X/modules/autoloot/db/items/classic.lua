
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[0] =
{
   'Black Vitriol',
   'Blue Power Crystal',
   'Green Power Crystal',
   'Large Venom Sac',
   'Light Feather',
   'Red Power Crystal',
   'Small Barnacled Clam',
   'Small Venom Sac',
   'Yellow Power Crystal',
   'Winterfall Spirit Beads'
}

X.Autoloot.ignore[0] =
{
   'Devilsaur Leather',
   'Gold Ore',
   'Green Whelp Scale',
   'Guardian Stone',
   'Heavy Hide',
   'Ironweb Spider Silk',
   'Light Hide',
   'Medium Hide',
    'Raptor Hide',
   'Rugged Hide',
   'Shadow Silk',
   'Silver Ore',
   'Spider\'s Silk',
   'Thick Hide',
   'Thick Murloc Scale',
   'Thick Spider\'s Silk',
   'Turtle Scale',
   'Warbear Leather'
}