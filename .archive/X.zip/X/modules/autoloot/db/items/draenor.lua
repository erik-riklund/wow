
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[5] = {
   
   
}

X.Autoloot.ignore[5] = {
   
   
}