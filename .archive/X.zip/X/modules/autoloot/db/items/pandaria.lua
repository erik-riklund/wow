
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.custom[4] = {
   'Life Spirit',
   'Infinite Thread of Critical Strike',
   'Infinite Thread of Haste',
   'Infinite Thread of Leech',
   'Infinite Thread of Mastery',
   'Infinite Thread of Power',
   'Infinite Thread of Speed',
   'Infinite Thread of Stamina',
   'Infinite Thread of Versatility',
   'Perpetual Thread of Critical Strike',
   'Perpetual Thread of Haste',
   'Perpetual Thread of Leech',
   'Perpetual Thread of Mastery',
   'Perpetual Thread of Power',
   'Perpetual Thread of Speed',
   'Perpetual Thread of Stamina',
   'Perpetual Thread of Versatility',
   'Temporal Thread of Critical Strike',
   'Temporal Thread of Haste',
   'Temporal Thread of Leech',
   'Temporal Thread of Mastery',
   'Temporal Thread of Power',
   'Temporal Thread of Speed',
   'Temporal Thread of Stamina',
   'Temporal Thread of Versatility',
   'Thread of Critical Strike',
   'Thread of Haste',
   'Thread of Leech',
   'Thread of Mastery',
   'Thread of Power',
   'Thread of Speed',
   'Thread of Stamina',
   'Thread of Versatility',
   'Plump Intestines',
   'Water Spirit'
}

X.Autoloot.ignore[4] = {
   
   'Golden Lotus'
}