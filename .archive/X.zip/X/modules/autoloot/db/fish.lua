
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot['fish'] = {
   'Deviate Fish',
   'Dull Spined Clam',
   'Firefin Snapper',
   'Lightning Eel',
   'Oily Blackmouth',
   'Pygmy Suckerfish',
   'Stonescale Eel'
}