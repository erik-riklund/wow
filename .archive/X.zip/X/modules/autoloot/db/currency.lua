
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot.currency = {
   
   -- Shadowlands
   "Stygia",
   "Grateful Offering",
   
   -- Mists of Pandaria
   "Lesser Charm of Good Fortune",
   
   -- Archaeology
   "Tol'vir Archaeology Fragment",
   "Fossil Archaeology Fragment",
   "Highborne Archaeology Fragment",
   "Troll Archaeology Fragment",
   "Dwarf Archaeology Fragment",
   "Nerubian Archaeology Fragment",
   "Draenor Clans Archaeology Fragment",
   "Vrykul Archaeology Fragment",
   "Draenei Archaeology Fragment",
   "Pandaren Archaeology Fragment",
   "Drust Archaeology Fragment",
   "Demonic Archaeology Fragment",
   "Zandalari Archaeology Fragment",
   "Night Elf Archaeology Fragment",
   "Orc Archaeology Fragment",
   "Ogre Archaeology Fragment",
   "Highmountain Tauren Archaeology Fragment",
   "Mantid Archaeology Fragment",
   "Arakkoa Archaeology Fragment",
   "Mogu Archaeology Fragment",

   -- Special events
   "Bronze"
}