
-- X by Ghuul (2023)

local _, X = ...

X.Autoloot['containers'] = {
   -- Classic
   'Iron Bound Trunk',
   'Small Barnacled Clam',
   'Tightly Sealed Trunk'
}