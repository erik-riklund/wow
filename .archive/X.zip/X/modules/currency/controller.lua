
-- X by Ghuul (2023)

local _, X = ...

local C = {}
local TF = _G["TokenFrame"]

X:SetDebug("currency", false)

local GetCurrencyListSize = C_CurrencyInfo.GetCurrencyListSize
local GetCurrencyListInfo = C_CurrencyInfo.GetCurrencyListInfo
local ExpandCurrencyList = C_CurrencyInfo.ExpandCurrencyList

----------------------------------------

function C:UpdateTokenStates()
   local tokens = X:GetV("token/state", true) or {}
   
   for i = 1, GetCurrencyListSize() do
      local token = GetCurrencyListInfo(i)
      if token.isHeader then
         tokens[token.name] = token.isHeaderExpanded
      end
   end
   
   X:SetV("token/state",tokens,true)
end

function C:GetIndexList()
   local index = {}
   
   for i = 1, GetCurrencyListSize() do
      local token = GetCurrencyListInfo(i)
      if  token.isHeader then
         tinsert(index,{ID=token.name,x=i,EXPANDED=token.isHeaderExpanded})
      end
   end
   
   return index
end

function C:ToggleTokens()
   local index = self:GetIndexList()
   local tokens = X:GetV("token/state",true) or nil
   
   if tokens == nil then
      self:UpdateTokenStates()
      tokens = X:GetV("token/state",true)
   end
   
   for i = 1, #index do
      if index[i].EXPANDED ~= tokens[index[i].ID] then
         if tokens[index[i].ID] == nil then
            tokens[index[i].ID] = false
         end
         
         ExpandCurrencyList(index[i].x,tokens[index[i].ID])
         X:Debug("currency", "Toggling token at index ".. index[i].x)
         
         self:ToggleTokens()
         return
      end
   end
end

----------------------------------------

TF:HookScript("OnShow", function(self)
   if X:IsModuleActive("currency") then
      if X:GetV("token/init", true) == nil then
         X:SetV("token/init", true, true)
         C:UpdateTokenStates()
      end
      
      C:ToggleTokens()
   end
end)

TF:HookScript("OnHide", function(self)
   if X:IsModuleActive("currency") then C:UpdateTokenStates() end
end)