
-- X by Ghuul (2023)

local _, X = ...

X_Tweaks = {
   --
   -- Automatically remove the crafting equipment related visual buffs?
   
   ['NoCraftingGearVisuals'] = true
}

