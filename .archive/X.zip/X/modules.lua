
-- X by Ghuul (2023)

local _, X = ...

X.modules = {
   -- Selective Autoloot:
   ['autoloot'] = true,
   
   -- Advanced bag sorter:
   ['cleaner'] = true,
   
   -- Currency tab state memory:
   ['currency'] = true,
   
   -- Automatated merchant functions:
   ['merchant'] = false,
   
   -- Questlog state memory:
   ['questlog'] = true,
    
    -- Improved recipe tooltip:
    ['recipe-tooltip'] = false,
   
   -- Reputation tab state memory:
   ['reputation'] = true,
   
   -- Additional tooltip information:
   ['tooltip'] = true,
   
   -- Tradeskill window state memory:
   ['tradeskill'] = true
}
