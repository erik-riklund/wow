--- @meta

--    ____                      _                       
--   / ___|___   __ _ ___ _ __ (_)_ __  _ __   ___ _ __ 
--  | |   / _ \ / _` / __| '_ \| | '_ \| '_ \ / _ \ '__|
--  | |__| (_) | (_| \__ \ |_) | | | | | | | |  __/ |   
--   \____\___/ \__, |___/ .__/|_|_| |_|_| |_|\___|_|   
--              |___/    |_|                            

--
--- @class core.context
--- 
--- @field data dictionary<string, unknown>
--- @field export fun(self: core.context, id: string, object: unknown)
--- @field import fun(self: core.context, id: string): unknown
--
