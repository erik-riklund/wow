--    ____                      _
--   / ___|___   __ _ ___ _ __ (_)_ __  _ __   ___ _ __
--  | |   / _ \ / _` / __| '_ \| | '_ \| '_ \ / _ \ '__|
--  | |__| (_) | (_| \__ \ |_) | | | | | | | |  __/ |
--   \____\___/ \__, |___/ .__/|_|_| |_|_| |_|\___|_|
--              |___/    |_|

local _, context = ...
--- @cast context core.context

local setmetatable = setmetatable

--#region (framework context imports)

--- @type framework.frame
local frame = context:import('frame')

--- @type plugin.base_context
local plugin = context:import('plugin')

--- @type module.network
local network = context:import('module/network')

--- @type module.plugins
local plugin_manager = context:import('module/plugins')

--- @type utility.collection.map
local map = context:import('utility/collection/map')

--- @type utility.collection.list
local list = context:import('utility/collection/list')

--#endregion

--
-- ?
--

--- @type module.events
local event_handler =
{
  --
  -- ?
  --

  listeners = map(
    {
      ADDON_LOADED = map()
    }
  ),

  --
  -- ?
  --

  register_listener = function(self, listener)
    --- @type list
    local listeners

    --#region: ?
    -- ?
    --#endregion

    if listener.event == 'ADDON_LOADED' then
      local addon_name = listener.owner.id
      local addons = self.listeners:get('ADDON_LOADED') --[[@as map]]

      if not addons:has(addon_name) then
        addons:set(addon_name, list())
      end

      listeners = addons:get(addon_name) --[[@as list]]
      listener.recurring = false -- note: an addon will only be loaded once.
    end

    --#region: ?
    -- ?
    --#endregion

    if listener.event ~= 'ADDON_LOADED' then
      if not self.listeners:has(listener.event) then
        frame:register_event(listener.event)
        self.listeners:set(listener.event, list())
      end

      listeners = self.listeners:get(listener.event) --[[@as list]]
    end

    --#region: ?
    -- ?
    --#endregion

    listeners:insert(
      {
        owner = listener.owner,
        callback = listener.callback,
        identifier = listener.identifier,
        recurring = (listener.recurring == true)

      } --[[@as events.listener]]
    )
  end,

  --
  -- ?
  --

  unregister_listener = function(self, listener)
    if listener.event == 'ADDON_LOADED' then
      throw('?')
    end


  end,

  --
  -- ?
  --

  invoke_event = function(self, event, ...)
    --- @type list
    local listeners

    --#region: ?
    -- ?
    --#endregion

    if event == 'ADDON_LOADED' then
      local addon = plugin_manager.normalize_id(...)

      print(addon)
    end

    --#region: ?
    -- ?
    --#endregion

    if event ~= 'ADDON_LOADED' then end

    --#region: ?
    -- ?
    --#endregion

    -- todo: what?
  end
}

--
-- ?
--

local event_api =
{
  __index =
  {
    --
    -- ?
    --

    listen = function(self, listener) end,

    --
    -- ?
    --

    silence = function(self, listener) end

  } --[[@as events.API]]
}

--
-- ?
--

--- @type plugin.initialize
local initialize = function(self, callback)
  self.event:listen({ event = 'ADDON_LOADED', callback = callback })
end

--
-- ?
--

network:monitor(
  plugin, 'PLUGIN_ADDED',
  {
    callback = function(payload)
      local target = (payload --[[@as table]]).plugin --[[@as plugin.base_context]]

      target.event = setmetatable({ parent = target }, event_api)
      target.initialize = initialize
    end
  }
)

--
-- ?
--

frame:register_event_handler(
  function(event, ...)
    event_handler:invoke_event(event, ...)
  end
)

--
-- ?
--

context:export('module/events', event_handler)
